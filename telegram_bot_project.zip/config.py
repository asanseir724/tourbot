
# config.py
BOT_TOKEN = "YOUR_BOT_TOKEN"
API_ID = "YOUR_API_ID"
API_HASH = "YOUR_API_HASH"

# Database configuration
DATABASE_CONFIG = {
    'dbname': 'your_database',
    'user': 'your_username',
    'password': 'your_password',
    'host': 'localhost',
    'port': 5432,
}

# Required channel ID for user subscription
REQUIRED_CHANNEL_ID = "@your_channel_id"
